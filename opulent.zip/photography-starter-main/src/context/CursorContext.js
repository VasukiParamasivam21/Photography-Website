import React from 'react';

const CursorContext = () => {
  return <div>CursorContext</div>;
};

export default CursorContext;
