import React from 'react';

const AnimRoutes = () => {
  return <div>AnimRoutes</div>;
};

export default AnimRoutes;
