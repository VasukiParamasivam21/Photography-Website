import React from 'react';

const MobileNav = () => {
  return <div>MobileNav</div>;
};

export default MobileNav;
